<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title>Create User</title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div>
				<h1 class="text-center">Update User Detail</h1>
				<hr>
			</div>
			<form class="row" action="backend.php" method="post">
				<div class="mb-3">
					<label for="FName" class="text-info form-label">Name:</label>
					<input type="text" class="form-group" name="FName" id="FName" required>
				</div>
				<div class="mb-3">
					<label for="FEmail" class="text-info form-label">Email:</label>
					<input type="email" class="form-group" name="FEmail" id="FEmail" required>
				</div>
				<div class="mb-3">
					<label for="FUsername" class="text-info form-label">Username</label>
					<input type="text" class="form-group" name="FUsername" id="FUsername" pattern="[A-Za-z0-9]{6,}" required>
				</div>
				<div class="mb-3"> 
					<label  for="FPassword" class="text-info form-label">Password:</label>
					<input type="Password" class="form-group" name="FPassword" id="FPassword" pattern="[A-Za-z0-9]{8}" required>
				</div>
				<div class="mb-3">
					<label for="FPhone" class="text-info form-label">Phone:</label>
					<input type="number" class="form-group" name="FPhone" id="FPhone" pattern="[0-9]{10}" min="6666666666" max="9999999999" required>
				</div>
				<button class="btn btn-dark" style="width:100px" onclick="Userdetail()">Submit</button>
				<input type="hidden" name="" id="hidden_user_id">
			</form>
		</div>
	</div>
	
</body>
</html>
