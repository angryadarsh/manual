<?php 
 
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$db = 'ajax';

	$conn = mysqli_connect($servername,$username,$password,$db);

	extract($_POST);

	if (isset($_POST['Name']) && isset($_POST['Email']) && isset($_POST['Username']) && isset($_POST['Password']) && isset($_POST['Phone']))
	{
		// code...
	$sql = "INSERT INTO ajaxf(Name, Email, Username, Password, Phone) VALUES ('".$Name."','".$Email."','".$Username."','".$Password."','".$Phone."')";

	$result = mysqli_query($conn,$sql);

	if ($result) {
		// code...
		echo "data added successfully";
		header("location:index.php");
	}else{
		echo "Some error occured";
	}

	}
	//display data 
	if (isset($_POST['readrecord'])) {
		// code...
		$data = '<table class = "table table-bordered table-striped">
						<tr>
						<th>No.</th>
						<th>Name</th>
						<th>Email</th>
						<th>Username</th>
						<th>Password</th>
						<th>Phone</th>
						<th>Edit</th>
						<th>Delete</th>
						</tr>';

		$display = "SELECT * FROM ajaxf";
		$query = mysqli_query($conn,$display);

		$nrow = mysqli_num_rows($query);

		if ($nrow >0 ) {
			// code...
			$number = 1;
			while($nrow = mysqli_fetch_array($query)){

				$data .='<tr>
				<td>'.$number.'</td>
				<td>'.$nrow['Name'].'</td>
				<td>'.$nrow['Email'].'</td>
				<td>'.$nrow['Username'].'</td>
				<td>'.$nrow['Password'].'</td>
				<td>'.$nrow['Phone'].'</td>
				<td><button onclick = "Userdetail('.$nrow['Id'].')" class="btn btn-warning">Edit</button></td>
				<td><button onclick = "DeleteUser('.$nrow['Id'].')" class="btn btn-danger">Delete</button></td>
				</tr>';

				$number++;
			}
		}
		$data .='</table>';
		echo $data;


	}

	//delete user details
if(isset($_POST['deleteid'])){
	$userid = $_POST['deleteid'];
	$delquery = "DELETE FROM ajaxf WHERE Id = '$userid' ";
	mysqli_query($conn,$delquery);
}
	

	
 	
?>