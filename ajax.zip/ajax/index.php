<?php 
 
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$db = 'ajax';

	$conn = mysqli_connect($servername,$username,$password,$db);

	$ViewData = "SELECT * FROM ajaxf;";
	$result = mysqli_query($conn,$ViewData);

	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title> Ajax Form Practice </title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="text-center bg-primary text-warning "><h1>Ajax Curd Practice</h1>
			   <hr>
			</div>
			<div class="mt-3 d-flex justify-content-end">
				<hr>
				<!--<button class="btn btn-primary" style="width: 100px;" id="" onclick="create.php">create User</button>-->
				<button class="btn btn-warning " style="width: 100px;" ><a  class = "text-dark" href="create.php"><b>Create User</b></a></button>
				
			
			</div>
			
			
			<div>
				<h1>All Records</h1>
				<hr>
			</div>
			<div id="read_contents">
				

			</div>
		</div>
	</div>

	<script type="text/javascript">
		$(document).ready(function(){
			readRecords();
		});
			
			function readRecords(){
				var readrecord = "readrecord";
				$.ajax({
					url:'backend.php',
					type:'post',
					data:{

						readrecord:readrecord
					},
					success:function(data,status){
						$('#read_contents').html(data)
					}

				});
			}

			function Record()
			{
				var Name = $('Name').val();
				var Email = $('Email').val();
				var Username = $('Username').val();
				var Password = $('Password').val();
				var Phone = $('Phone').val();

				$.ajax({
					url:'backend.php',
					type:'post',
					data:{
						Name:Name,
						Email:Email,
						Username:Username,
						Password:Password,
						Phone:Phone
					},
					success:function(data,status){
						readRecords();
					}

			});
			}


		///delete 
		function DeleteUser(deleteid){
			var conf = confirm("are you sure");
			if (conf==true) {
				$.ajax({
					url:"backend.php",
					type:"post",
					data:{deleteid:deleteid },
					success:function(data,status){
						readRecords();
					}
				});
			}
		}
		///update function
		/*function Userdetail(Id){
			$('#hidden_user_id').val(Id);

			$.post("backend.php",{
				Id:Id},function(data,status){

					var user = JSON.parse(data);
					$('#FName').val(user.Name);
					$('#FEmail').val(user.Email);
					$('#FUsername').val(user.Username);
					$('#FPassword').val(user.Password);
					$('#FPhone').val(user.Phone);
				}


			
			);*/

		

		
	</script>
</body>
</html>